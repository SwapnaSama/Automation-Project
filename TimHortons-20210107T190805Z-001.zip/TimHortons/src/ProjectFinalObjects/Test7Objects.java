package ProjectFinalObjects;

public class Test7Objects {

}
